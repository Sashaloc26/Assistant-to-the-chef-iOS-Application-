//
//  BaseViewController.swift
//  Kitchen Helper
//
//  Created by Саша Тихонов on 29/01/2024.
//

import UIKit

class BaseViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func makeConstraints() {}
    
    func setupViews() {}
}
